The RibbonImageSource project is not part of the downloadable code for the book, but it's included as it's the source project for the picture showing the ribbon controls.

Also note that the ExcelVBAInterop project in broken in beta 2.