To compile this simple application (outside of Visual Studio) please open a Visual Studio 2010 command prompt, navigate to this folder, and then type the following...

  csc NotepadForms.cs

This will create an .exe that you can run.