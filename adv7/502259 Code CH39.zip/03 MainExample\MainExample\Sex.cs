﻿using System;

namespace MainExample
{
    /// <summary>
    /// Defines gender
    /// </summary>
    public enum Sex
    {
        Male,
        Female
    }
}
