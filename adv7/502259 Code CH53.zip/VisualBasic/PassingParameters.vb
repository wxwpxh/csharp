Public Class PassingParameters
    Public Sub ChangeVal(ByRef x As Integer)
        x = 3
    End Sub



End Class
