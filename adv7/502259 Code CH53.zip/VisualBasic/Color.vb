Public Enum Color
    Red
    Green
    Blue
End Enum
