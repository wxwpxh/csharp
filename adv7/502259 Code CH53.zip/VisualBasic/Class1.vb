Public Class Class1
    Public Sub Foo1(ByVal i As Integer)

    End Sub

    Public Function Foo2(ByVal i As Integer) As Integer
        Return 2 * i
    End Function

End Class
