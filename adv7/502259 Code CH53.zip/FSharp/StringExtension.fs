﻿module Wrox.ProCSharp.Languages.StringExtension

type System.String with
    member this.Foo = printfn "String.Foo"

