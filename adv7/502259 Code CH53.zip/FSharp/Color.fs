﻿module Color

type Color =
| Red = 0
| Green = 1
| Blue = 2

