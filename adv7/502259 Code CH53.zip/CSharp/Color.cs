using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp
{
    public enum Color
    {
        Red, Green, Blue
    }
}
