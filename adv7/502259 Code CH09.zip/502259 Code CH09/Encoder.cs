using System;

namespace Encoder
{
    class Program
    {
        static void Main()
        {
            string greetingText = "Hello from all the guys at Wrox Press. ";
            greetingText += "We do hope you enjoy this book as much as we enjoyed writing it.";

            for (int i = (int)'z'; i >= (int)'a'; i--)
            {
                char old1 = (char)i;
                char new1 = (char)(i + 1);
                greetingText = greetingText.Replace(old1, new1);
            }

            for (int i = (int)'Z'; i >= (int)'A'; i--)
            {
                char old1 = (char)i;
                char new1 = (char)(i + 1);
                greetingText = greetingText.Replace(old1, new1);
            }

            Console.WriteLine("Encoded:\n" + greetingText);
            Console.ReadLine();
        }
    }
}
