﻿namespace Wrox.ProCSharp.Messaging
{
   public class Course
   {
      public string Title { get; set; }
   }

}
