﻿namespace Wrox.ProCSharp.Messaging
{
   public class Customer
   {
      public string Company { get; set; }
      public string Contact { get; set; }
   }

}
