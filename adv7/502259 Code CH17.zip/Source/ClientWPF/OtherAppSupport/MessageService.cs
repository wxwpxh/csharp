﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OtherAppSupport
{
    public class MessageService
    {
        public string GetMessage()
        {
            return "This is the message.";
        }
    }
}
