using System;
using System.Workflow.ComponentModel.Design;

namespace CustomActivities
{
    /// <summary>
    /// Defines a designer for the WriteLineActivity
    /// </summary>
    [ActivityDesignerTheme(typeof(WriteLineTheme))]
	public class WriteLineDesigner : ActivityDesigner
	{
	}
}
