use Northwind
go

--
-- Procedure to select all rows from the Region table
--
CREATE PROCEDURE RegionSelect AS
  SET NOCOUNT OFF;

  SELECT * FROM Region ;
GO
