discAmt = .25
retAmt = amt
if amt > 25.00:
  retAmt = amt-(amt*discAmt)
