﻿using System;

public enum Suit
{
    Club, Diamond, Heart, Spade
}