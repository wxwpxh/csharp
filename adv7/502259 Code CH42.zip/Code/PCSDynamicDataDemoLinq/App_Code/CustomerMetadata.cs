﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

/// <summary>
/// Summary description for CustomerMetadata
/// </summary>
[ScaffoldTable(true)]
public class CustomerMetadata
{
    //[ScaffoldColumn(false)]
    //public object Address { get; set; }
}