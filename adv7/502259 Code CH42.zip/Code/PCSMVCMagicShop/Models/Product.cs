﻿using System.ComponentModel.DataAnnotations;

namespace PCSMVCMagicShop.Models
{
   [MetadataType(typeof(ProductMetadata))]
   public partial class Product
   {
   }
}