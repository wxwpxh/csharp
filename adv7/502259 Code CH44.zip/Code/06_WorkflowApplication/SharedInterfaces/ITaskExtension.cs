﻿using System;

namespace SharedInterfaces
{
    public interface ITaskExtension
    {
        void ExecuteTask(string taskName);
    }
}
