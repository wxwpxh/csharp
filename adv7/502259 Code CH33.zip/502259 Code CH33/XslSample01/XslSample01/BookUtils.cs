﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XslSample01
{
    class BookUtils
    {
        public BookUtils() { }

        public string ShowText()
        {
            return "This came from the ShowText method!";
        }
    }
}
