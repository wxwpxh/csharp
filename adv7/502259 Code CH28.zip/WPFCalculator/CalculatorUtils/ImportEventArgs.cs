﻿using System;

namespace Wrox.ProCSharp.MEF
{
    public class ImportEventArgs : EventArgs
    {
        public string StatusMessage { get; set; }
    }
}
