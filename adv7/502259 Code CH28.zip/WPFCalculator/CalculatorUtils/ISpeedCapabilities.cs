﻿namespace Wrox.ProCSharp.MEF
{
    public interface ISpeedCapabilities
    {
        Speed Speed { get; }
    }
}
