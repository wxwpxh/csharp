﻿namespace Wrox.ProCSharp.MEF
{
    public interface IOperation
    {
        string Name { get; }
        int NumberOperands { get; }
    }
}
