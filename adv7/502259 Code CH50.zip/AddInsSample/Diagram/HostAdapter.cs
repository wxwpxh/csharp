﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Diagram
{
   public class HostAdapter : HostView
   {
      public ICalcContract ICalcContract
      {
         get
         {
            throw new System.NotImplementedException();
         }
         set
         {
         }
      }
   }
}
