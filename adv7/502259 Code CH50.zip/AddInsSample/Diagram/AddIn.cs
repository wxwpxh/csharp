﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Diagram
{
   public class AddIn : AddInView
   {
      public override void GetOperations()
      {
         throw new NotImplementedException();
      }

      public override void Operate()
      {
         throw new NotImplementedException();
      }
   }
}
