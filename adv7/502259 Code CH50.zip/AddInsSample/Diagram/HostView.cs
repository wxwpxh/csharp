﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Diagram
{
   public abstract class HostView
   {
      public void GetOperations()
      {
         throw new System.NotImplementedException();
      }

      public void Operate()
      {
         throw new System.NotImplementedException();
      }
   }
}
