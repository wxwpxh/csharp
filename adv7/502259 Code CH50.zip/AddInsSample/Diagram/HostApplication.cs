﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Diagram
{
   public class HostApplication
   {
      public HostView HostView
      {
         get
         {
            throw new System.NotImplementedException();
         }
         set
         {
         }
      }
   }
}
