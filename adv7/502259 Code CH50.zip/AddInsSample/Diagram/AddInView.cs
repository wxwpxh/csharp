﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Diagram
{
   public abstract class AddInView
   {
      public abstract void GetOperations();


      public abstract void Operate();

   }
}
